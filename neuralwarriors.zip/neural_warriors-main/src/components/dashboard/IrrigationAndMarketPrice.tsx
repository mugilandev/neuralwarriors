import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Droplets, TrendingUp, RefreshCw } from 'lucide-react';

type Tab = 'irrigation' | 'market';

interface IrrigationRow {
  id: string;
  crop: string;
  schedule: string;
  duration: string;
  status: 'scheduled' | 'active' | 'completed';
}

interface MarketRow {
  id: string;
  commodity: string;
  unit: string;
  price: number;
  change: number; // % change for display
}

const initialIrrigation: IrrigationRow[] = [
  { id: '1', crop: 'Paddy', schedule: 'Mon, Wed, Fri', duration: '2 hrs', status: 'scheduled' },
  { id: '2', crop: 'Cotton', schedule: 'Tue, Thu', duration: '1.5 hrs', status: 'active' },
  { id: '3', crop: 'Sugarcane', schedule: 'Daily', duration: '3 hrs', status: 'completed' },
  { id: '4', crop: 'Maize', schedule: 'Mon, Thu', duration: '2 hrs', status: 'scheduled' },
];

const baseCommodities: { commodity: string; unit: string; basePrice: number }[] = [
  { commodity: 'Rice', unit: '/kg', basePrice: 28 },
  { commodity: 'Wheat', unit: '/kg', basePrice: 24 },
  { commodity: 'Cotton', unit: '/quintal', basePrice: 6200 },
  { commodity: 'Sugarcane', unit: '/quintal', basePrice: 340 },
  { commodity: 'Tomato', unit: '/kg', basePrice: 45 },
  { commodity: 'Onion', unit: '/kg', basePrice: 32 },
];

function randomChange(): number {
  return (Math.random() - 0.5) * 10;
}

export function IrrigationAndMarketPrice() {
  const [activeTab, setActiveTab] = useState<Tab>('irrigation');

  const [marketPrices, setMarketPrices] = useState<MarketRow[]>(() =>
    baseCommodities.map((c, i) => ({
      id: String(i + 1),
      commodity: c.commodity,
      unit: c.unit,
      price: c.basePrice + (Math.random() - 0.5) * 10,
      change: randomChange(),
    }))
  );

  const refreshPrices = () => {
    setMarketPrices((prev) =>
      prev.map((row) => {
        const base = baseCommodities.find((c) => c.commodity === row.commodity)!;
        const newPrice = Math.max(5, base.basePrice + (Math.random() - 0.5) * 20);
        const change = ((newPrice - row.price) / row.price) * 100;
        return { ...row, price: Math.round(newPrice * 10) / 10, change };
      })
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-premium p-6 overflow-hidden"
    >
      {/* Tab bar */}
      <div className="flex rounded-xl bg-secondary/60 p-1 mb-6">
        <button
          onClick={() => setActiveTab('irrigation')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-all touch-target ${
            activeTab === 'irrigation'
              ? 'bg-primary text-primary-foreground shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
          }`}
        >
          <Droplets className="w-5 h-5" />
          Irrigation
        </button>
        <button
          onClick={() => {
            setActiveTab('market');
            refreshPrices();
          }}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-medium transition-all touch-target ${
            activeTab === 'market'
              ? 'bg-primary text-primary-foreground shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
          }`}
        >
          <TrendingUp className="w-5 h-5" />
          Market Price
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'irrigation' && (
          <motion.div
            key="irrigation"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
            transition={{ duration: 0.2 }}
            className="overflow-x-auto"
          >
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-2 font-semibold text-foreground">Crop</th>
                  <th className="text-left py-3 px-2 font-semibold text-foreground">Schedule</th>
                  <th className="text-left py-3 px-2 font-semibold text-foreground">Duration</th>
                  <th className="text-left py-3 px-2 font-semibold text-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {initialIrrigation.map((row) => (
                  <tr key={row.id} className="border-b border-border/60 hover:bg-secondary/40">
                    <td className="py-3 px-2 text-foreground">{row.crop}</td>
                    <td className="py-3 px-2 text-muted-foreground">{row.schedule}</td>
                    <td className="py-3 px-2 text-muted-foreground">{row.duration}</td>
                    <td className="py-3 px-2">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${
                          row.status === 'active'
                            ? 'bg-accent/20 text-accent-foreground'
                            : row.status === 'completed'
                              ? 'bg-primary/15 text-primary'
                              : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        )}

        {activeTab === 'market' && (
          <motion.div
            key="market"
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <p className="text-muted-foreground text-sm">Tap Market Price to refresh prices.</p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={refreshPrices}
                className="flex items-center gap-2 px-3 py-2 bg-secondary rounded-lg text-sm font-medium hover:bg-secondary/80 touch-target"
              >
                <RefreshCw className="w-4 h-4" />
                Refresh
              </motion.button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-2 font-semibold text-foreground">Commodity</th>
                    <th className="text-right py-3 px-2 font-semibold text-foreground">Price (₹)</th>
                    <th className="text-right py-3 px-2 font-semibold text-foreground">Change</th>
                  </tr>
                </thead>
                <tbody>
                  {marketPrices.map((row) => (
                    <tr key={row.id} className="border-b border-border/60 hover:bg-secondary/40">
                      <td className="py-3 px-2 text-foreground">
                        {row.commodity}
                        <span className="text-muted-foreground font-normal">{row.unit}</span>
                      </td>
                      <td className="py-3 px-2 text-right font-medium text-foreground">
                        ₹{row.price.toFixed(1)}
                      </td>
                      <td className="py-3 px-2 text-right">
                        <span
                          className={
                            row.change >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                          }
                        >
                          {row.change >= 0 ? '+' : ''}
                          {row.change.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
