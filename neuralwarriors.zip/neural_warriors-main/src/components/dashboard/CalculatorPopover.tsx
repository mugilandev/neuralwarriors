import { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const CALC_KEYS = [
  'C', '±', '%', '÷',
  '7', '8', '9', '×',
  '4', '5', '6', '-',
  '1', '2', '3', '+',
  '0', '.', '=',
];

export function CalculatorPopover({
  isOpen,
  onClose,
  anchorRef,
}: {
  isOpen: boolean;
  onClose: () => void;
  anchorRef: React.RefObject<HTMLButtonElement | null>;
}) {
  const [display, setDisplay] = useState('0');
  const [prev, setPrev] = useState<string | null>(null);
  const [op, setOp] = useState<string | null>(null);
  const [replaceNext, setReplaceNext] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target) &&
        anchorRef.current &&
        !anchorRef.current.contains(e.target as Node)
      ) {
        onClose();
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose, anchorRef]);

  const handleInput = (key: string) => {
    if (key === 'C') {
      setDisplay('0');
      setPrev(null);
      setOp(null);
      setReplaceNext(false);
      return;
    }
    if (key === '±') {
      setDisplay((d) => (d.startsWith('-') ? d.slice(1) : '-' + d));
      return;
    }
    if (key === '%') {
      setDisplay(String(parseFloat(display) / 100));
      return;
    }
    if (['÷', '×', '-', '+'].includes(key)) {
      if (prev !== null && op !== null) {
        const a = parseFloat(prev);
        const b = parseFloat(display);
        let result = 0;
        if (op === '+') result = a + b;
        if (op === '-') result = a - b;
        if (op === '×') result = a * b;
        if (op === '÷') result = b === 0 ? 0 : a / b;
        const nextDisplay = String(Math.round(result * 1e10) / 1e10);
        setDisplay(nextDisplay);
        setPrev(nextDisplay);
      } else {
        setPrev(display);
      }
      setOp(key);
      setReplaceNext(true);
      return;
    }
    if (key === '=') {
      if (prev === null || op === null) return;
      const a = parseFloat(prev);
      const b = parseFloat(display);
      let result = 0;
      if (op === '+') result = a + b;
      if (op === '-') result = a - b;
      if (op === '×') result = a * b;
      if (op === '÷') result = b === 0 ? 0 : a / b;
      setDisplay(String(Math.round(result * 1e10) / 1e10));
      setPrev(null);
      setOp(null);
      setReplaceNext(true);
      return;
    }
    if (key === '.') {
      if (replaceNext) {
        setDisplay('0.');
        setReplaceNext(false);
        return;
      }
      if (display.includes('.')) return;
      setDisplay((d) => (d === '0' ? '0.' : d + '.'));
      return;
    }
    // digit
    if (replaceNext) {
      setDisplay(key === '0' ? '0' : key);
      setReplaceNext(false);
      return;
    }
    setDisplay((d) => (d === '0' && key !== '.' ? key : d + key));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={panelRef}
          initial={{ opacity: 0, scale: 0.95, y: -8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -8 }}
          transition={{ duration: 0.15 }}
          className="absolute right-0 top-full mt-2 w-[260px] rounded-2xl border border-border bg-card p-3 shadow-xl z-50"
        >
          <div className="mb-3 rounded-xl bg-muted/80 px-3 py-4 text-right font-mono text-2xl font-semibold text-foreground tabular-nums min-h-[48px] flex items-center justify-end">
            {display}
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {CALC_KEYS.map((key) => {
              const isOp = ['÷', '×', '-', '+', '='].includes(key);
              const isZero = key === '0';
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => handleInput(key)}
                  className={`rounded-xl font-medium transition-all active:scale-95 ${
                    isOp
                      ? 'bg-accent text-accent-foreground hover:opacity-90'
                      : key === 'C' || key === '±' || key === '%'
                        ? 'bg-muted text-muted-foreground hover:bg-muted/80'
                        : 'bg-secondary text-foreground hover:bg-secondary/80'
                  } ${isZero ? 'col-span-2' : ''}`}
                  style={{ minHeight: 44 }}
                >
                  {key}
                </button>
              );
            })}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
