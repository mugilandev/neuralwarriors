import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Calculator } from 'lucide-react';
import { Header } from '@/components/dashboard/Header';
import { VoiceButton } from '@/components/dashboard/VoiceButton';
import { WeatherWidget } from '@/components/dashboard/WeatherWidget';
import { AIScanner } from '@/components/dashboard/AIScanner';
import { Marketplace } from '@/components/dashboard/Marketplace';
import { IrrigationAndMarketPrice } from '@/components/dashboard/IrrigationAndMarketPrice';
import { CalculatorPopover } from '@/components/dashboard/CalculatorPopover';
import { useTranslation } from '@/contexts/AppContext';

export default function Dashboard() {
  const t = useTranslation();
  const [showCalculator, setShowCalculator] = useState(false);
  const calculatorButtonRef = useRef<HTMLButtonElement>(null);

  return (
    <div className="min-h-screen bg-gradient-cream flex flex-col">
      <Header />

      {/* Calculator - fixed below nav, right corner, not in nav */}
      <div className="fixed top-16 right-4 z-50 md:top-[4.5rem] md:right-6">
        <motion.button
          ref={calculatorButtonRef}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowCalculator((v) => !v)}
          className="p-3 rounded-xl bg-card border border-border shadow-lg text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors touch-target"
          aria-label="Calculator"
        >
          <Calculator className="w-6 h-6" />
        </motion.button>
        <CalculatorPopover
          isOpen={showCalculator}
          onClose={() => setShowCalculator(false)}
          anchorRef={calculatorButtonRef}
        />
      </div>

      <main className="container mx-auto px-4 py-6 md:py-10 flex-1 flex flex-col">
        {/* Welcome Section - farming motion */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8 animate-float-gentle"
        >
          <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-2">
            {t('welcome')}
          </h2>
          <p className="text-muted-foreground">
            AI-powered crop diagnostics at your fingertips
          </p>
        </motion.div>

        {/* Voice Assistant - Centered and Prominent */}
        <motion.section
          id="voice"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1, type: 'spring', stiffness: 120, damping: 20 }}
          className="voice-assistant-card mb-8 cursor-default scroll-mt-24"
        >
          <VoiceButton />
        </motion.section>

        {/* Main Grid - Scanner, Market, Irrigation (left) | Weather (right) */}
        <div className="grid gap-6 md:gap-8 lg:grid-cols-2">
          <div className="space-y-6 md:space-y-8">
            <motion.section
              id="scanner"
              initial={{ opacity: 0, x: -24 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 100, damping: 18 }}
              className="scroll-mt-24"
            >
              <AIScanner />
            </motion.section>

            <motion.section
              id="marketplace"
              initial={{ opacity: 0, x: -24 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, type: 'spring', stiffness: 100, damping: 18 }}
              className="scroll-mt-24 max-h-[420px] overflow-y-auto"
            >
              <Marketplace />
            </motion.section>
          </div>

          <div className="space-y-6 md:space-y-8">
            <motion.section
              id="weather"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 100, damping: 18 }}
              className="scroll-mt-24"
            >
              <WeatherWidget />
            </motion.section>

            <motion.section
              id="irrigation"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.35, type: 'spring', stiffness: 100, damping: 18 }}
              className="scroll-mt-24 max-h-[420px] overflow-y-auto"
            >
              <IrrigationAndMarketPrice />
            </motion.section>
          </div>
        </div>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 py-6 text-center border-t border-border"
        >
          <p className="text-muted-foreground text-sm">
            © 2026 All rights received - Neural warriors
          </p>
        </motion.footer>
      </main>
    </div>
  );
}
